package com.teamProject.UKA.apiData.dto;

import lombok.Data;

@Data
public class ResponseDTO {
	private HeaderDTO header;
	private BodyDTO body;

}
