package com.teamProject.UKA.apiData.dto;

import java.util.List;

import lombok.Data;

@Data
public class ItemsDTO {
	private List<AnimalDTO> item;

}
