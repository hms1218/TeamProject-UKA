import { useEffect, useState } from "react";
import { SidoApiData } from "../api/AnimalSidoApiData";

export default function useSidoCodes() {
  const [codes, setCodes] = useState([]);

  useEffect(() => {
    // 실제 API로 fetch하는 경우는 fetchSidoCodes().then(setCodes);
    setCodes(SidoApiData);
  }, []);

  return codes;
}
