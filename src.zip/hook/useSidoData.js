import { useState, useEffect } from "react";
import { SidoApiData } from "../api/AnimalCommonApiData"; // 경로에 맞게 조정

export default function useSidoData() {
    const [sidoList, setSidoList] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        let isMounted = true;
        SidoApiData().then(data => {
            if (isMounted) {
                setSidoList(data || []);
                setLoading(false);
            }
        });
        return () => { isMounted = false; };
    }, []);

    return { sidoList, loading };
}
