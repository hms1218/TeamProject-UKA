package com.teamProject.UKA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UkaApplicationTests {

	@Test
	void contextLoads() {
	}

}
