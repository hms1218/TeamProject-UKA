package com.teamProject.UKA.apiData.dto;

import lombok.Data;

@Data
public class HeaderDTO {
    private String resultCode;
    private String resultMsg;
    private String reqNo;
}
