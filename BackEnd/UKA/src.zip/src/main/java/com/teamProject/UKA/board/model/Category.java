package com.teamProject.UKA.board.model;

public enum Category {
	NOTICE, CHAT, REVIEW;
}
