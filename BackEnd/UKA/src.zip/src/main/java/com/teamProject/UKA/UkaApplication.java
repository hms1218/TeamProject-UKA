package com.teamProject.UKA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UkaApplication {

	public static void main(String[] args) {
		SpringApplication.run(UkaApplication.class, args);
	}

}
