package com.teamProject.UKA.apiData.dto;

import lombok.Data;

@Data
public class ApiResponseDTO {
	private ResponseDTO response;
}
