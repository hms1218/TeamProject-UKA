const API_URL = process.env.REACT_APP_ALL_SIGUNGU_API_URL;
const API_KEY = process.env.REACT_APP_ALL_ANIMAL_API_KEY;
const PAGE_SIZE = 100;

// 	시도 API 호출
export const fetchRegionCodeMap = async (urp_cd) => {
    let pageIndex = 1;

    try {
        const params = {
            serviceKey: API_KEY,
            numOfRows: PAGE_SIZE,
            pageNo: pageIndex,
        };
        const response = await fetch (
            `${API_URL}?serviceKey=${params.serviceKey}&pageNo=${params.pageNo}&numOfRows=${params.numOfRows}&upr_cd=${urp_cd}&_type=json`
        );

        const json = await response.json();
        const SidoData = json?.response?.body?.items.item;

        return SidoData;
    } catch (error) {
        return console.error("API 요청 실패:", error);
    }
};