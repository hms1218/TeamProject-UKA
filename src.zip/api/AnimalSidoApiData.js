const API_URL = process.env.REACT_APP_ALL_SIDO_API_URL;
const API_KEY = process.env.REACT_APP_ALL_ANIMAL_API_KEY;
const PAGE_SIZE = 50;

// 시도(시/도) API 호출 함수
export const SidoApiData = async () => {
    let pageIndex = 1;
    try {
        const params = {
            serviceKey: API_KEY,
            numOfRows: PAGE_SIZE,
            pageNo: pageIndex,
        };
        const response = await fetch(
            `${API_URL}?serviceKey=${params.serviceKey}&pageNo=${params.pageNo}&numOfRows=${params.numOfRows}&_type=json`
        );
        const json = await response.json();
        // 응답 데이터에서 실제 시도 데이터만 추출 (배열)
        const SidoData = json?.response?.body?.items?.item;
        return SidoData; // [{orgCd: "...", orgdownNm: "..."}]
    } catch (error) {
        console.error("API 요청 실패:", error);
        return [];
    }
};
